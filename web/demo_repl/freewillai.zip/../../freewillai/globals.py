class Global:
    provider_endpoint = 'http://127.0.0.1:8545'
